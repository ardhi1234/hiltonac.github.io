# CSC-424-2017-Full-Stack
A full stack website development project by the 2017 graduates of School of Computing, USM
