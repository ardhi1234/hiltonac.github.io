/**
 * Created by Trevor on 2/18/2017.
 */
// config/database.js
module.exports = {

    'url' : 'mongodb://localhost:27017/test' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
//'url' : 'mongodb://127.0.0.1:27017/test'
};